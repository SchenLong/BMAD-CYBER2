# Claude AI Instructions

## General Principles

- **Use deterministic rather than agentic when possible** - Prefer explicit, repeatable approaches over autonomous exploration
- **Make a general backup of the repo before starting a new stage** - Create backups in `team/backups/` with timestamp
- **Do not create folders/subfolders without checking first if they exist** - Verify before creating
- **All dev, planning, qa, security files go under `team/`** - This is a gitignored folder
- **All public and user documentation goes under `/docs/user`** - Keep user-facing docs separate

## Pre-Task Checklist

- **Refer to `team/lessonslearned.md` before starting** - Check if it exists, review past lessons to avoid repeating mistakes
- **Verify current repo state** - Ensure clean working directory before starting work

## Planning & Execution

- **Stick to the plan, do not improvise** - Do not add features without user confirmation
- **Use at least 3 agents/subagents in parallel with no timeout** - Agents should ONLY research/gather info, NEVER modify files directly
- **Always use fresh context windows** - For every task, agent, and subagent
- **Create an index in every working file** - Refer to it to save context tokens
- **Only load necessary context** - For a given story/task from the working document if any

## Quality & Security

- **Always test what is built/fixed/changed before closing the task**
- **After a change, review dependencies** - Check if any paths, imports, or dependencies in files need updating
- **Update the working document at the end of a task**
- **100% pass rate required** - All security issues must be addressed, no postponing, no "addressing later"
- **Run security scan before committing** - Ensure no new vulnerabilities introduced
- **Do not close a task unless:** all tests pass AND all security issues are addressed OR we enter a loop OR find a breaker (including medium and low severity issues)

## File Organization

- **Make sure each file is created in its final folder** - Or moved there upon creation, do not mess the repo
- **Update relevant documents after closing a task** when relevant
- **Never commit without ensuring:** the repo is clean, contains no PII, all docs/files in proper folders, all private files properly gitignored

## Lessons Learned

- **Always log mistakes to `team/lessonslearned.md`** - Document errors, root cause, and what was learned. Create file if it doesn't exist.
- **Always refer to `team/lessonslearned.md` before starting a task** - Check if file exists, review past lessons to avoid repeating mistakes

## Next Steps

- **When finished, announce the next step of the plan**
