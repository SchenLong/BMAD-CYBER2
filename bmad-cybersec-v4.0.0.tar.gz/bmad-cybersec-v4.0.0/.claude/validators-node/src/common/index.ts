/**
 * BMAD Validators - Common Module
 * ================================
 * Re-exports all common utilities.
 */

export { AuditLogger } from './audit-logger.js';
export { OverrideManager } from './override-manager.js';
export { resolvePath, isPathInRepo, getProjectDir, normalizePath, getRelativePath, sanitizePath, sanitizeErrorMessage, preprocessPath, PROJECT_ROOT_PLACEHOLDER, EXTERNAL_PLACEHOLDER } from './path-utils.js';
export { getToolInputFromStdin, getToolInputFromStdinSync } from './stdin-parser.js';
export { printBlockMessage, printWarning, printOverrideConsumed } from './block-message.js';
export type { BlockMessageOptions } from './block-message.js';
export { sendAlert, sendAlertSync, shouldAlert, alertCritical, alertBlocked, alertWarning } from './alerting.js';
export type { AlertPayload } from './alerting.js';
export { safeMatch, safeTest, safeBatchMatch, truncateForRegex, getMaxInputLength, getRegexTimeout } from './safe-regex.js';
export type { SafeMatchResult } from './safe-regex.js';
export {
  SessionContext,
  checkSessionPermission,
  consumeSessionPermission,
  initSession,
  getSessionId,
} from './session-context.js';
export type {
  PermissionGrant,
  SessionContextState,
  PermissionCheckResult as SessionPermissionCheckResult,  // Aliased to avoid conflict with token-validator
} from './session-context.js';
