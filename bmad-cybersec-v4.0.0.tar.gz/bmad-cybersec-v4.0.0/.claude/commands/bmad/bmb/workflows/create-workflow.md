---
description: 'Create structured standalone workflows using markdown-based step architecture'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @src/bmb/workflows/create-workflow/workflow.md, READ its entire contents and follow its directions exactly!
