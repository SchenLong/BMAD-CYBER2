---
description: 'Run after epic completion to review overall success, extract lessons learned, and explore if new information emerged that might impact the next epic'
---

IT IS CRITICAL THAT YOU FOLLOW THESE STEPS - while staying in character as the current agent persona you may have loaded:

<steps CRITICAL="TRUE">
1. Always LOAD the FULL @src/core/tasks/workflow.xml
2. READ its entire contents - this is the CORE OS for EXECUTING the specific workflow-config @src/bmgd/workflows/4-production/retrospective/workflow.yaml
3. Pass the yaml path src/bmgd/workflows/4-production/retrospective/workflow.yaml as 'workflow-config' parameter to the workflow.xml instructions
4. Follow workflow.xml instructions EXACTLY as written to process and follow the specific workflow config and its instructions
5. Save outputs after EACH section when generating any documents from templates
</steps>
