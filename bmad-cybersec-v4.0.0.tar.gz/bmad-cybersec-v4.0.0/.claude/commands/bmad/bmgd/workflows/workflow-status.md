---
description: 'Lightweight status checker - answers ""what should I do now?"" for any game dev agent. Reads YAML status file for workflow tracking. Use workflow-init for new projects.'
---

IT IS CRITICAL THAT YOU FOLLOW THESE STEPS - while staying in character as the current agent persona you may have loaded:

<steps CRITICAL="TRUE">
1. Always LOAD the FULL @src/core/tasks/workflow.xml
2. READ its entire contents - this is the CORE OS for EXECUTING the specific workflow-config @src/bmgd/workflows/workflow-status/workflow.yaml
3. Pass the yaml path src/bmgd/workflows/workflow-status/workflow.yaml as 'workflow-config' parameter to the workflow.xml instructions
4. Follow workflow.xml instructions EXACTLY as written to process and follow the specific workflow config and its instructions
5. Save outputs after EACH section when generating any documents from templates
</steps>
